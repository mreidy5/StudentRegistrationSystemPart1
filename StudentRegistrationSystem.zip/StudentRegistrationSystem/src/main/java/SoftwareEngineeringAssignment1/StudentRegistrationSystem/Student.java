package SoftwareEngineeringAssignment1.StudentRegistrationSystem;


import java.util.*;


public class Student 
{
    //private variables
	
	private String FirstName;
	private String LastName;
	private int Age;
	private Date DOB;
	private int ID;
	private String UserName;
	private String CourseName;
	private String CourseCode;
	private ArrayList<String> Modules;
	private ArrayList<String> ModulesIDs;
	
	//Constructor Method
	public Student(String FirstName, String LastName, int Age, Date DOB, int ID, String UserName,
				   String CourseName, String CourseCode, ArrayList<String> Modules, ArrayList<String> ModulesIDs)
	{
		this.FirstName = FirstName;
		this.LastName = LastName;
		this.Age = Age;
		this.DOB = DOB;
		this.ID = ID;
		this.UserName = UserName;
		this.CourseName = CourseName;
		this.CourseCode = CourseCode;
		this.Modules = Modules;
		this.ModulesIDs = ModulesIDs;
	}
	
	public String getFirstName() {
		return FirstName;
	}
	
	public void setFirstName(String FirstName) {
		this.FirstName = FirstName;
	}
	
	public String getLastName() {
		return LastName;
	}
	
	public void setLastName(String LastName) {
		this.LastName = LastName;
	}
	
	public int getAge() {
		return Age;
	}
	
	public void setAge(int Age) {
		this.Age = Age;
	}
	
	public Date getDOB() {
		return DOB;
	}
	
	public void setDOB(Date DOB) {
		this.DOB = DOB;
	}
	
	public int getID() {
		return ID;
	}
	
	public void setID(int ID) {
		this.ID = ID;
	}
	
	public String getUserName() {
		return UserName = FirstName + LastName + Age;
	}
	
	public String getCourseName() {
		return CourseName;
	}
	
	public void setCourseName(String CourseName) {
		this.CourseName = CourseName; 
	}
	
	public String getCourseCode() {
		return CourseCode;
	}
	
	public void setCourseCode(String CourseCode) {
		this.CourseCode = CourseCode;
	}
	
	public ArrayList<String> getModules() {
		return Modules;
	}
	
	public void setModules(ArrayList<String> Modules) {
		this.Modules = Modules;
	}
	
	public ArrayList<String> getModulesIDs() {
		return ModulesIDs;
	}
	
	public void setModulesIDs(ArrayList<String> ModulesIDs) {
		this.ModulesIDs = ModulesIDs;
	}
	
	public String toString(){
		return "FirstName: " + this.FirstName + ", LastName: " + this.LastName + ", Age: " + this.Age + ", Date of Birth: " + this.DOB + ", ID: " + this.ID + ", UserName: " 
			+ this.UserName + ", CourseName: " +  this.CourseName + ", CourseCode: " + this.CourseCode + ", Modules: " + Arrays.toString(Modules.toArray()) + ", Module IDs: " + Arrays.toString(ModulesIDs.toArray());
	}
}
