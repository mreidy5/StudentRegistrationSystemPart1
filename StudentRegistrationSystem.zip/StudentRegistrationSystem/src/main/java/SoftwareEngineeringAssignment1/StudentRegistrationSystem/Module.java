package SoftwareEngineeringAssignment1.StudentRegistrationSystem;

import java.util.*;

public class Module {

	private String ModuleName;
	private String ID;
	private ArrayList<String> Students;
	private ArrayList<String> Lecturers;
	
	//Constructor Method
	public Module(String ModuleName, String ID, ArrayList<String> Students, ArrayList<String> Lecturers)
	{
		this.ModuleName = ModuleName;
		this.ID = ID;
		this.Students = Students;
		this.Lecturers = Lecturers;
	}
	
	public String getModuleName() {
		return ModuleName;
	}
	
	public void setModuleName(String ModuleName) {
		this.ModuleName = ModuleName;
	}
	
	public String getID() {
		return ID;
	}
	
	public void setID(String ID) {
		this.ID = ID;
	}
	
	public ArrayList<String> getStudents() {
		return Students;
	}
	
	public void setStudents(ArrayList<String> Students) {
		this.Students = Students;
	}
	
	public ArrayList<String> getLecturers() {
		return Lecturers;
	}
	
	public void setLecturers(ArrayList<String> Lecturers) {
		this.Lecturers = Lecturers;
	}
	
}
